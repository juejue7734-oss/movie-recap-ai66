package com.movierecap.ai.domain

import android.net.Uri
import java.util.UUID

enum class AppLanguage(val label: String) {
    ENGLISH("English"), MYANMAR("Myanmar"), THAI("Thai"), CHINESE("Chinese"), HINDI("Hindi"), KOREAN("Korean"), JAPANESE("Japanese"), INDONESIAN("Indonesian"), VIETNAMESE("Vietnamese"), SPANISH("Spanish"), FRENCH("French"); override fun toString() = label
}
enum class VoiceProfile(val label: String, val description: String, val providerVoiceId: String) {
    STORYTELLER_MALE("Storyteller Male", "Warm and cinematic", "storyteller_male"),
    STORYTELLER_FEMALE("Storyteller Female", "Warm and cinematic", "storyteller_female"),
    DEEP_MALE("Deep Male", "Low and dramatic", "deep_male"),
    CALM_FEMALE("Calm Female", "Soft and clear", "calm_female"),
    ENERGETIC_MALE("Energetic Male", "Fast and exciting", "energetic_male"),
    BRIGHT_FEMALE("Bright Female", "Friendly and lively", "bright_female");
    override fun toString() = label
}
enum class AspectRatio(val label: String, val value: String) { VERTICAL("Vertical", "9:16"), LANDSCAPE("Landscape", "16:9"), SQUARE("Square", "1:1"); override fun toString() = "$label ($value)" }
data class Project(val id: String = UUID.randomUUID().toString(), val name: String, val sourceUri: Uri? = null, val sourceFileName: String? = null, val durationMs: Long = 0, val updatedAt: Long = System.currentTimeMillis(), val isComplete: Boolean = false, val language: AppLanguage = AppLanguage.ENGLISH, val voiceProfile: VoiceProfile = VoiceProfile.STORYTELLER_MALE, val length: RecapLength = RecapLength.MEDIUM, val customTargetSeconds: Int? = null, val script: String = "", val scenes: List<SceneSegment> = emptyList(), val narrationSegments: List<NarrationSegment> = emptyList(), val subtitleCues: List<SubtitleCue> = emptyList(), val subtitleStyle: SubtitleStyle = SubtitleStyle(), val audioMix: AudioMixSettings = AudioMixSettings(), val syncOffsetMs: Long = 0L, val voiceAudioUri: Uri? = null, val voiceGenerated: Boolean = false)
data class ExportedVideo(val id: String = UUID.randomUUID().toString(), val fileName: String, val uri: Uri? = null, val durationMs: Long = 0, val exportedAt: Long = System.currentTimeMillis(), val resolution: ExportResolution = ExportResolution.AUTO, val aspectRatio: AspectRatio = AspectRatio.VERTICAL, val quality: ExportQuality = ExportQuality.HIGH, val savedToGallery: Boolean = false)
data class AppSettings(val defaultLanguage: AppLanguage = AppLanguage.ENGLISH, val voiceLanguage: AppLanguage = AppLanguage.ENGLISH, val subtitleLanguage: AppLanguage = AppLanguage.ENGLISH, val voiceProfile: VoiceProfile = VoiceProfile.STORYTELLER_MALE, val quality: String = "1080p", val aspectRatio: AspectRatio = AspectRatio.VERTICAL, val musicVolume: Float = 0.65f, val darkTheme: Boolean = false, val aiProvider: AiProvider = AiProvider.NONE)
