package com.movierecap.ai.domain

import android.net.Uri

data class NarrationSegment(
    val index: Int,
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val sceneIndex: Int,
    val audioUri: Uri? = null
) { val durationMs: Long get() = (endMs - startMs).coerceAtLeast(0L) }

data class SubtitleCue(val index: Int, val text: String, val startMs: Long, val endMs: Long)

enum class SubtitlePosition(val label: String) { TOP("Top"), CENTER("Center"), BOTTOM("Bottom"); override fun toString() = label }

data class SubtitleStyle(
    val enabled: Boolean = true,
    val fontSizeSp: Int = 22,
    val position: SubtitlePosition = SubtitlePosition.BOTTOM,
    val outlined: Boolean = true
)

data class AudioMixSettings(
    val musicEnabled: Boolean = false,
    val narrationVolume: Float = 1f,
    val musicVolume: Float = 0.2f,
    val originalAudioEnabled: Boolean = false,
    val originalAudioVolume: Float = 0.15f,
    val duckMusicDuringNarration: Boolean = true
)

data class SynchronizedTimeline(
    val scenes: List<SceneSegment> = emptyList(),
    val narration: List<NarrationSegment> = emptyList(),
    val subtitles: List<SubtitleCue> = emptyList(),
    val syncOffsetMs: Long = 0L,
    val isSynchronized: Boolean = false
)
