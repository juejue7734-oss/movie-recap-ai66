package com.movierecap.ai.domain

enum class RecapLength(val label: String, val targetSeconds: Int) { SHORT("Short", 60), MEDIUM("Medium", 180), LONG("Long", 420), CUSTOM("Custom", 0); override fun toString() = label }
data class SceneSegment(val index: Int, val startMs: Long, val endMs: Long, val narration: String)
data class VideoAnalysis(val durationMs: Long, val sceneCount: Int, val frameCount: Int, val hasAudio: Boolean, val analyzedAt: Long = System.currentTimeMillis())
data class RecapDraft(
    val video: VideoInfo? = null, val analysis: VideoAnalysis? = null, val language: AppLanguage = AppLanguage.ENGLISH,
    val length: RecapLength = RecapLength.MEDIUM, val customTargetSeconds: Int? = null, val script: String = "", val voiceProfile: VoiceProfile = VoiceProfile.STORYTELLER_MALE,
    val scenes: List<SceneSegment> = emptyList(), val narrationSegments: List<NarrationSegment> = emptyList(),
    val subtitleCues: List<SubtitleCue> = emptyList(), val subtitleStyle: SubtitleStyle = SubtitleStyle(),
    val audioMix: AudioMixSettings = AudioMixSettings(), val syncOffsetMs: Long = 0L, val voiceAudioUri: android.net.Uri? = null,
    val voiceGenerated: Boolean = false, val isSaved: Boolean = false
)
data class AiProviderConfig(val provider: AiProvider = AiProvider.NONE, val endpoint: String = "", val model: String = "")
enum class AiProvider(val label: String, val keyName: String) { NONE("Not configured", ""), OPENAI("OpenAI", "OPENAI_API_KEY"), GEMINI("Google Gemini", "GEMINI_API_KEY"); override fun toString() = label }
