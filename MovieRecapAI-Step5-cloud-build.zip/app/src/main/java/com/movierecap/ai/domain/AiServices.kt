package com.movierecap.ai.domain

import android.net.Uri

interface RecapAiService {
    suspend fun generateRecap(video: Uri, analysis: VideoAnalysis, language: AppLanguage, length: RecapLength): String
}

class MissingApiKeyException(provider: AiProvider) : IllegalStateException("${provider.label} is not configured. Add ${provider.keyName} on a secure backend or developer build.")

/**
 * Provider adapters intentionally do not contain API keys. Production should call a secured backend.
 * The Android app only receives configuration-safe provider metadata and generated content.
 */
class OpenAiRecapService(private val apiKeyProvider: () -> String?) : RecapAiService {
    override suspend fun generateRecap(video: Uri, analysis: VideoAnalysis, language: AppLanguage, length: RecapLength): String {
        val key = apiKeyProvider()?.takeIf { it.isNotBlank() } ?: throw MissingApiKeyException(AiProvider.OPENAI)
        // TODO Step 2 backend: upload authorized video frames/audio and call OpenAI Responses API.
        @Suppress("UNUSED_VARIABLE") val ignored = key
        return ""
    }
}

class GeminiRecapService(private val apiKeyProvider: () -> String?) : RecapAiService {
    override suspend fun generateRecap(video: Uri, analysis: VideoAnalysis, language: AppLanguage, length: RecapLength): String {
        val key = apiKeyProvider()?.takeIf { it.isNotBlank() } ?: throw MissingApiKeyException(AiProvider.GEMINI)
        // TODO Step 2 backend: upload authorized video frames/audio and call Gemini API.
        @Suppress("UNUSED_VARIABLE") val ignored = key
        return ""
    }
}
