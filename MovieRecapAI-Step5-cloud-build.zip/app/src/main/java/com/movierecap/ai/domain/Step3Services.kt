package com.movierecap.ai.domain

import android.net.Uri

interface TtsService {
    suspend fun synthesize(text: String, language: AppLanguage, voice: String? = null): Uri
}

enum class VoiceGender { MALE, FEMALE, PROVIDER_DEFAULT }

interface SentenceTimestampService { fun splitAndTime(script: String, targetDurationMs: Long, sceneCount: Int): List<NarrationSegment> }
interface SubtitleService { fun createCues(segments: List<NarrationSegment>): List<SubtitleCue> }
interface AudioMixService { suspend fun mix(narration: Uri, music: Uri?, originalVideo: Uri?, settings: AudioMixSettings): Uri }
interface SynchronizationService { fun synchronize(scenes: List<SceneSegment>, narration: List<NarrationSegment>, offsetMs: Long = 0L): SynchronizedTimeline }
interface PreviewTimelinePlayer { fun play(); fun pause(); fun seekTo(positionMs: Long) }
interface Mp4ExportPreparer { suspend fun prepare(timeline: SynchronizedTimeline, mix: AudioMixSettings): Uri? }

/** Safe placeholder used until a backend/provider is connected; it never embeds an API key. */
class ConfiguredTtsService(private val apiKeyProvider: () -> String?) : TtsService {
    override suspend fun synthesize(text: String, language: AppLanguage, voice: String?): Uri {
        require(!apiKeyProvider().isNullOrBlank()) { "TTS is not configured. Add a provider key on the secure backend." }
        error("Connect the provider backend before requesting production audio.")
    }
}
