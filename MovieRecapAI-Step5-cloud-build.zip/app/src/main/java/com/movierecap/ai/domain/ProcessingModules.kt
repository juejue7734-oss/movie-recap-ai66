package com.movierecap.ai.domain

import android.net.Uri

interface VideoInput { suspend fun inspect(uri: Uri): VideoInfo }
data class VideoInfo(val fileName: String, val durationMs: Long, val uri: Uri)
interface VideoAnalyzer { suspend fun analyze(video: VideoInfo, onProgress: (Float) -> Unit): VideoAnalysis }
interface AiScriptGenerator { suspend fun generateScript(video: Uri, language: AppLanguage): String }
interface VoiceGenerator { suspend fun synthesize(text: String, language: AppLanguage): Uri? }
interface AudioVideoSynchronizer { suspend fun synchronize(video: Uri, voice: Uri, musicVolume: Float): Uri? }
interface SubtitleGenerator { suspend fun generate(text: String, language: AppLanguage): Uri? }
interface VideoRendererLegacy { suspend fun render(video: Uri, subtitles: Uri?, aspectRatio: AspectRatio, quality: String): Uri? }
interface GallerySaver { suspend fun saveMp4(source: Uri, displayName: String): Uri? }
interface SocialSharer { fun shareMp4(uri: Uri) }
