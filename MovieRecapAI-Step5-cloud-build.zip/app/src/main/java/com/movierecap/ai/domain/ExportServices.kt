package com.movierecap.ai.domain

import android.net.Uri

interface AudioMixer { suspend fun mix(narration: Uri?, music: Uri?, originalVideo: Uri?, settings: ExportSettings, onProgress: (Float) -> Unit): Uri? }
interface SubtitleRenderer { suspend fun render(sourceVideo: Uri, cues: List<SubtitleCue>, style: SubtitleStyle, onProgress: (Float) -> Unit): Uri }
interface VideoRenderer { suspend fun render(plan: RenderPlan, onProgress: (Float) -> Unit): Uri? }
data class RenderPlan(val sourceVideo: Uri, val scenes: List<SceneSegment>, val narration: List<NarrationSegment>, val subtitles: List<SubtitleCue>, val settings: ExportSettings, val audio: AudioMixSettings)
interface ExportManager { suspend fun export(plan: RenderPlan, onProgress: (RenderProgress) -> Unit): ExportResult }
data class ExportResult(val renderedUri: Uri?, val error: String? = null)
interface ShareManager { fun shareMp4(uri: Uri) }
interface ExportOpener { fun open(uri: Uri) }

/** Step 4 adapter boundary. A Media3 Transformer/FFmpeg implementation can be injected here. */
class ModularExportManager(private val renderer: VideoRenderer, private val gallerySaver: GallerySaver) : ExportManager {
    override suspend fun export(plan: RenderPlan, onProgress: (RenderProgress) -> Unit): ExportResult = runCatching {
        onProgress(RenderProgress("Preparing video", .05f)); onProgress(RenderProgress("Processing scenes", .2f)); onProgress(RenderProgress("Mixing audio", .4f)); onProgress(RenderProgress("Rendering subtitles", .6f)); onProgress(RenderProgress("Encoding video", .82f))
        val rendered = renderer.render(plan) { value -> onProgress(RenderProgress("Encoding video", .6f + value.coerceIn(0f, 1f) * .25f)) } ?: return ExportResult(null, "The video renderer returned no output.")
        onProgress(RenderProgress("Finalizing file", .94f)); val saved = gallerySaver.saveMp4(rendered, "movie_recap_${System.currentTimeMillis()}.mp4") ?: return ExportResult(null, "Android Gallery could not save the MP4.")
        onProgress(RenderProgress("Saving video", 1f)); ExportResult(saved)
    }.getOrElse { ExportResult(null, it.message ?: "Video rendering failed.") }
}
