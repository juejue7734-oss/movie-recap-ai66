package com.movierecap.ai.domain

import android.net.Uri

enum class ExportQuality(val label: String, val bitrateFactor: Float) { STANDARD("Standard", .65f), HIGH("High", 1f), MAXIMUM("Maximum", 1.35f); override fun toString() = label }
enum class ExportResolution(val label: String) { AUTO("Auto"), P720("720p"), P1080("1080p"); override fun toString() = label }
enum class ExportPreset(val label: String, val ratio: AspectRatio, val quality: ExportQuality) { VERTICAL_SHORT("Vertical Short Video", AspectRatio.VERTICAL, ExportQuality.HIGH), LANDSCAPE("Landscape Video", AspectRatio.LANDSCAPE, ExportQuality.HIGH), SQUARE("Square Video", AspectRatio.SQUARE, ExportQuality.HIGH); override fun toString() = label }

data class ExportSettings(
    val aspectRatio: AspectRatio = AspectRatio.VERTICAL,
    val quality: ExportQuality = ExportQuality.HIGH,
    val resolution: ExportResolution = ExportResolution.AUTO,
    val narrationVolume: Float = 1f,
    val musicVolume: Float = .2f,
    val originalAudioVolume: Float = .15f,
    val subtitlesEnabled: Boolean = true,
    val preset: ExportPreset? = null
)

data class RenderProgress(val stage: String, val fraction: Float, val failed: Boolean = false, val cancelled: Boolean = false)
data class ExportHistory(
    val id: String,
    val fileName: String,
    val uri: Uri? = null,
    val durationMs: Long = 0L,
    val resolution: ExportResolution = ExportResolution.AUTO,
    val aspectRatio: AspectRatio = AspectRatio.VERTICAL,
    val quality: ExportQuality = ExportQuality.HIGH,
    val createdAt: Long = System.currentTimeMillis(),
    val savedToGallery: Boolean = false
)
